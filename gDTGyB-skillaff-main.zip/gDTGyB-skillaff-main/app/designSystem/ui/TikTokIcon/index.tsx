import { TikTokOutlined } from '@ant-design/icons'
import React from 'react'

export const TikTokIcon: React.FC = () => {
  return <TikTokOutlined style={{ fontSize: '16px' }} />
}
