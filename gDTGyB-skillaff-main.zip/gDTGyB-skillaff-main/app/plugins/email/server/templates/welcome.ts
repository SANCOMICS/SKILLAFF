export const TemplateWelcome = `
<Card.Header>
  <h2>Welcome to SKILLFLOW</h2>
  <hr />
</Card.Header>

<Card.Body>
  <p>Your account is now active.</p>
</Card.Body>

<Card.Footer>
  <p>Sent by SKILLFLOW</p>
</Card.Footer>
  `.trim()
