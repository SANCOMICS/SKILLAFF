export type UploadFileType = {
  name: string
  buffer: Buffer
  mimetype: string
}
